import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors'
import { exec } from 'child_process';
const app = express();
const PORT = 5000;
// Middleware to parse JSON
app.use(express.json());
app.use(cors())
const baseFolderPath = ''; // Set your base folder path
// List files and folders in a specific path
app.get('/api/files', (req, res) => {
   const relativePath = req.query.path || ''; // Get path query parameter
   const targetPath = path.join(baseFolderPath, relativePath);
   fs.readdir(targetPath, { withFileTypes: true }, (err, entries) => {
       if (err) {
           return res.status(500).json({ error: 'Unable to read directory' });
       }
       // Return list of files and directories
       const items = entries.map((entry) => ({
           name: entry.name,
           isDirectory: entry.isDirectory(),
       }));
       res.json({ path: relativePath, items });
   });
});
// Download a file
app.get('/api/files/download', (req, res) => {
   const relativePath = req.query.path || '';
   const filePath = path.join(baseFolderPath, relativePath);
   if (!fs.existsSync(filePath)) {
       return res.status(404).json({ error: 'File not found' });
   }
   res.download(filePath);
});

app.post('/api/files/open', (req, res) => {
   const filePath = req.query.path; // Get the file path from the query
   if (!filePath) {
       return res.status(400).json({ error: 'File path is required' });
   }
   const fullPath = path.join(baseFolderPath, filePath); // Resolve the full file path
   // Use exec to open the file
   exec(`start "" "${fullPath}"`, (err) => {
       if (err) {
           console.error('Error opening file:', err);
           return res.status(500).json({ error: 'Unable to open file' });
       }
       res.json({ message: 'Opened successfully' });
   });
});

// Start the server
app.listen(PORT, () => {
 console.log(`Server is running on http://localhost:${PORT}`);
});