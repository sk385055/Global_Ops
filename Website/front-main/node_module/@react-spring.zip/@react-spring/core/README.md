# @react-spring/core

The platform-agnostic core of `react-spring`
