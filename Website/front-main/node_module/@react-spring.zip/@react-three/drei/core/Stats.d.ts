import * as React from 'react';
type Props = {
    showPanel?: number;
    className?: string;
    parent?: React.RefObject<HTMLElement>;
};
export declare function Stats({ showPanel, className, parent }: Props): null;
export {};
