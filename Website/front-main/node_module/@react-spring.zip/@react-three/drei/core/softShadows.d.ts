type SoftShadowsProps = {
    size?: number;
    samples?: number;
    focus?: number;
};
export declare function SoftShadows({ focus, samples, size }: SoftShadowsProps): null;
export {};
