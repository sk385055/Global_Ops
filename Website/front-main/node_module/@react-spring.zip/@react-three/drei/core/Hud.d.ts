import * as React from 'react';
type HudProps = {
    children: React.ReactNode;
    renderPriority?: number;
};
export declare function Hud({ children, renderPriority }: HudProps): React.JSX.Element;
export {};
