export declare function useAspect(width: number, height: number, factor?: number): [number, number, number];
