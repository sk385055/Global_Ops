export declare function AdaptiveDpr({ pixelated }: {
    pixelated?: boolean;
}): null;
