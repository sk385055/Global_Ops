import * as React from 'react';
export declare function MultiMaterial(props: JSX.IntrinsicElements['group']): React.JSX.Element;
