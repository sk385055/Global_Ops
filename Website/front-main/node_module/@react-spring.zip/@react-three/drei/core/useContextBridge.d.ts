import * as React from 'react';
export declare function useContextBridge(...contexts: Array<React.Context<any>>): ({ children }: {
    children: React.ReactNode;
}) => JSX.Element;
