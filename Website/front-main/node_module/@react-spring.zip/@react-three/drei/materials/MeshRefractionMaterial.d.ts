import * as THREE from 'three';
export declare const MeshRefractionMaterial: typeof THREE.ShaderMaterial & {
    key: string;
};
