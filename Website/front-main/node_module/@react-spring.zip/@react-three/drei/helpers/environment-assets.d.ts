export declare const presetsObj: {
    apartment: string;
    city: string;
    dawn: string;
    forest: string;
    lobby: string;
    night: string;
    park: string;
    studio: string;
    sunset: string;
    warehouse: string;
};
export type PresetsType = keyof typeof presetsObj;
