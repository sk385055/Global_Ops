export declare const version: number;
