# TODO:

## New functions

- fs.appendFile(filename, data, [options], callback)
- fs.chmod(path, mode, callback)
- fs.stat(path, callback)
- fs.watchFile(filename, [options], listener)
- fs.unwatchFile(filename, [listener])
- fs.watch(filename, [options], [listener])

## Implementation on existing functions

- support of mode in mkdir
- support of mode in writeFile
