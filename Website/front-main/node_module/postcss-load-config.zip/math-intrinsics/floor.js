'use strict';

/** @type {import('./abs')} */
module.exports = Math.floor;
