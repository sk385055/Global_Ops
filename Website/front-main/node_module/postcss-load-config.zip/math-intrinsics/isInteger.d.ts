declare function isInteger(argument: unknown): argument is number;

export = isInteger;