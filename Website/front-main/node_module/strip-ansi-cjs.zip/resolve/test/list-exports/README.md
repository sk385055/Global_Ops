# list-exports
Given a package name and a version number, or a path to a package.json, what specifiers does it expose?
