'use strict';

module.exports = 'indr';
