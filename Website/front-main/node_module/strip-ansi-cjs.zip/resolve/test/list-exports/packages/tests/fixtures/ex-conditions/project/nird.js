'use strict';

module.exports = 'nird';
