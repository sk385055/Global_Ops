'use strict';

module.exports = 'irnd';
