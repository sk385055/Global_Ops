'use strict';

module.exports = 'ndri';
