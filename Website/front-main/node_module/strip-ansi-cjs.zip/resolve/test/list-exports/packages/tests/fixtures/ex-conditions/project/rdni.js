'use strict';

module.exports = 'rdni';
