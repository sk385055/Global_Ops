'use strict';

module.exports = 'dnir';
