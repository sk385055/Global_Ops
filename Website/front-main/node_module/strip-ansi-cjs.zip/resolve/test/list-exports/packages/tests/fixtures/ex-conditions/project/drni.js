'use strict';

module.exports = 'drni';
