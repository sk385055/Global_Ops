'use strict';

module.exports = 'nidr';
