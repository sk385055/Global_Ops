'use strict';

module.exports = 'drin';
