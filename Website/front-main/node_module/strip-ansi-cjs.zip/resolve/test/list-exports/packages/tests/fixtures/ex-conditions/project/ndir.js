'use strict';

module.exports = 'ndir';
