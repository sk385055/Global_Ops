'use strict';

module.exports = 'default';
