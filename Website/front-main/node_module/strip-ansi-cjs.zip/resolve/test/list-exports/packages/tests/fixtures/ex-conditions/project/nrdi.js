'use strict';

module.exports = 'nrdi';
