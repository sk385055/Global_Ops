'use strict';

module.exports = 'dinr';
