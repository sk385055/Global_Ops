'use strict';

module.exports = 'nrid';
