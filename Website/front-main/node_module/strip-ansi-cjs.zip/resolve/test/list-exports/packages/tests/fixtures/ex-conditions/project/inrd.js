'use strict';

module.exports = 'inrd';
