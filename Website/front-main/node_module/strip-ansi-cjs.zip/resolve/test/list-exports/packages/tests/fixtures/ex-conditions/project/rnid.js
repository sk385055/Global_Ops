'use strict';

module.exports = 'rnid';
