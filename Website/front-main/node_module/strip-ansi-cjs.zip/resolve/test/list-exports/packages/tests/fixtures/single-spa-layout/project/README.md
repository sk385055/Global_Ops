# single-spa-layout

[![Build Status](https://travis-ci.com/single-spa/single-spa-layout.svg?branch=master)](https://travis-ci.com/single-spa/single-spa-layout)

[Full Documentation](https://single-spa.js.org/docs/layout-overview/)

A layout engine for single-spa applications.
