'use strict';

module.exports = 'dnri';
