'use strict';

module.exports = 'irdn';
