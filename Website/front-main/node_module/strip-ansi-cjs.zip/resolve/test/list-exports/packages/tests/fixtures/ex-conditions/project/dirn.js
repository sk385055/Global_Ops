'use strict';

module.exports = 'dirn';
