'use strict';

module.exports = 'idnr';
