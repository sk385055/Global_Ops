'use strict';

module.exports = 'rdin';
