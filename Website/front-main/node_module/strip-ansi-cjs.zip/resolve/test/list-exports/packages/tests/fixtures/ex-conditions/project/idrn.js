'use strict';

module.exports = 'idrn';
