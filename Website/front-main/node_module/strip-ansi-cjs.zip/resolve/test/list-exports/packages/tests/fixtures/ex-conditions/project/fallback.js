'use strict';

module.exports = 'fallback';
