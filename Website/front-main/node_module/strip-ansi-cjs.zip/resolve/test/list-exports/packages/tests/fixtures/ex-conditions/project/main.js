'use strict';

module.exports = 'main';
