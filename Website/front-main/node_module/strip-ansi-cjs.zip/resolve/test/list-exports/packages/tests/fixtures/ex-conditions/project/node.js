'use strict';

module.exports = 'node';
