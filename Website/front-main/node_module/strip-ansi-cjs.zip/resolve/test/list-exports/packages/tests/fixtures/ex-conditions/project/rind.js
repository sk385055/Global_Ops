'use strict';

module.exports = 'rind';
