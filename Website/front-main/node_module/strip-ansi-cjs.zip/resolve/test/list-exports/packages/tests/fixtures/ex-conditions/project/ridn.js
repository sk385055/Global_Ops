'use strict';

module.exports = 'ridn';
