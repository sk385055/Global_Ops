'use strict';

var supported;
try {
	// eslint-disable-next-line global-require
	supported = require('@ljharb/has-package-exports-patterns/patterns/pattern');
} catch (e) {
	supported = false;
}
module.exports = supported;
