'use strict';

module.exports = 'rndi';
