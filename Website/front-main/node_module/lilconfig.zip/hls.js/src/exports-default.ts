import Hls from './hls';

export default Hls;
