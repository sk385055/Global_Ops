
3.3.1 / 2020-06-18
==================

**fixes**
  * [[`0d94a24`](http://github.com/thenables/thenify/commit/0d94a24eb933bc835d568f3009f4d269c4c4c17a)] - fix: remove eval (#30) (Yiyu He <<dead_horse@qq.com>>)

3.3.0 / 2017-05-19
==================

  * feat: support options.multiArgs and options.withCallback (#27)
