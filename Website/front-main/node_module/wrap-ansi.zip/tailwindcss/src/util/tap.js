export function tap(value, mutator) {
  mutator(value)
  return value
}
