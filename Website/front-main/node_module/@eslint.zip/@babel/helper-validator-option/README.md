# @babel/helper-validator-option

> Validate plugin/preset options

See our website [@babel/helper-validator-option](https://babeljs.io/docs/babel-helper-validator-option) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-validator-option
```

or using yarn:

```sh
yarn add @babel/helper-validator-option
```
