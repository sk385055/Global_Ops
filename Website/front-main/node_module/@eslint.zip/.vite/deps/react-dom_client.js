import {
  require_client
} from "./chunk-2ZIDK4BD.js";
import "./chunk-RC3YDMAO.js";
import "./chunk-DRWLMN53.js";
import "./chunk-G3PMV62Z.js";
export default require_client();
//# sourceMappingURL=react-dom_client.js.map
