// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachQuarterOfInterval as fn } from "../eachQuarterOfInterval.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachQuarterOfInterval = convertToFP(fn, 1);

// Fallback for modularized imports:
export default eachQuarterOfInterval;
