// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addMonths as fn } from "../addMonths.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addMonths = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addMonths;
