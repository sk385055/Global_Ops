// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addMilliseconds as fn } from "../addMilliseconds.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addMilliseconds = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addMilliseconds;
