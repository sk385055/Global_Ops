export declare const closestIndexTo: import("./types.js").FPFn2<
  number | undefined,
  (string | number | Date)[],
  string | number | Date
>;
