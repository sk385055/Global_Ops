// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { compareDesc as fn } from "../compareDesc.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const compareDesc = convertToFP(fn, 2);

// Fallback for modularized imports:
export default compareDesc;
