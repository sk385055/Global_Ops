// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addDays as fn } from "../addDays.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addDays = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addDays;
