export declare const endOfSecond: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
