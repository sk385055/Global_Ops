"use strict";
exports.addSeconds = void 0;

var _index = require("../addSeconds.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const addSeconds = (exports.addSeconds = (0, _index2.convertToFP)(
  _index.addSeconds,
  2,
));
