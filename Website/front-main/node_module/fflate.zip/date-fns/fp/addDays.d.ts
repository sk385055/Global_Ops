export declare const addDays: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
