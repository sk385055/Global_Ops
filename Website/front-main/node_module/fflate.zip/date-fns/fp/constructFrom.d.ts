export declare const constructFrom: import("./types.js").FPFn2<
  Date,
  string | number | Date,
  string | number | Date
>;
