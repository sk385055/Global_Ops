export declare const differenceInMinutesWithOptions: import("./types.js").FPFn3<
  number,
  import("../differenceInMinutes.js").DifferenceInMinutesOptions | undefined,
  string | number | Date,
  string | number | Date
>;
