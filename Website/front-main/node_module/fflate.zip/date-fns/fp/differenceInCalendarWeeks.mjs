// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInCalendarWeeks as fn } from "../differenceInCalendarWeeks.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInCalendarWeeks = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInCalendarWeeks;
