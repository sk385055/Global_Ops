export declare const eachQuarterOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  | import("../eachQuarterOfInterval.js").EachQuarterOfIntervalOptions
  | undefined,
  import("../fp.js").Interval<Date>
>;
