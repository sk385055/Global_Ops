// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInCalendarMonths as fn } from "../differenceInCalendarMonths.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInCalendarMonths = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInCalendarMonths;
