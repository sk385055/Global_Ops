export declare const eachWeekendOfMonth: import("./types.js").FPFn1<
  Date[],
  Date
>;
