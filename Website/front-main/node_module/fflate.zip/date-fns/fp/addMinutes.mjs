// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addMinutes as fn } from "../addMinutes.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addMinutes = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addMinutes;
