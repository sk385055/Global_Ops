export declare const endOfMonth: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
