// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInDays as fn } from "../differenceInDays.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInDays = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInDays;
