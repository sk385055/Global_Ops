export declare const differenceInHoursWithOptions: import("./types.js").FPFn3<
  number,
  import("../differenceInHours.js").DifferenceInHoursOptions | undefined,
  string | number | Date,
  string | number | Date
>;
