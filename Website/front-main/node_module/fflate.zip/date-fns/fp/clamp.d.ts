export declare const clamp: import("./types.js").FPFn2<
  Date,
  import("../fp.js").Interval<Date>,
  string | number | Date
>;
