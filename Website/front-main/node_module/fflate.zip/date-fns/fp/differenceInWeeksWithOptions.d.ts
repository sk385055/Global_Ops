export declare const differenceInWeeksWithOptions: import("./types.js").FPFn3<
  number,
  import("../differenceInWeeks.js").DifferenceInWeeksOptions | undefined,
  string | number | Date,
  string | number | Date
>;
