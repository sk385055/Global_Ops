export declare const eachDayOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  import("../eachDayOfInterval.js").EachDayOfIntervalOptions | undefined,
  import("../fp.js").Interval<Date>
>;
