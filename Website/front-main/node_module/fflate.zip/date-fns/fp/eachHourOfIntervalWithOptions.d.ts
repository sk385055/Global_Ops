export declare const eachHourOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  import("../eachHourOfInterval.js").EachHourOfIntervalOptions | undefined,
  import("../fp.js").Interval<Date>
>;
