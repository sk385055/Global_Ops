export declare const endOfISOWeekYear: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
