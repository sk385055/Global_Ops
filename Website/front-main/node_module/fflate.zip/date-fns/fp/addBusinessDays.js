"use strict";
exports.addBusinessDays = void 0;

var _index = require("../addBusinessDays.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const addBusinessDays = (exports.addBusinessDays = (0, _index2.convertToFP)(
  _index.addBusinessDays,
  2,
));
