export declare const differenceInQuartersWithOptions: import("./types.js").FPFn3<
  number,
  import("../differenceInQuarters.js").DifferenceInQuartersOptions | undefined,
  string | number | Date,
  string | number | Date
>;
