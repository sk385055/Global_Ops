"use strict";
exports.eachMinuteOfInterval = void 0;

var _index = require("../eachMinuteOfInterval.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const eachMinuteOfInterval = (exports.eachMinuteOfInterval = (0,
_index2.convertToFP)(_index.eachMinuteOfInterval, 1));
