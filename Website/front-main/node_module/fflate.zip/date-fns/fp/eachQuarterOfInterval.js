"use strict";
exports.eachQuarterOfInterval = void 0;

var _index = require("../eachQuarterOfInterval.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const eachQuarterOfInterval = (exports.eachQuarterOfInterval = (0,
_index2.convertToFP)(_index.eachQuarterOfInterval, 1));
