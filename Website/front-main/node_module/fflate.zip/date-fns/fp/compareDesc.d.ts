export declare const compareDesc: import("./types.js").FPFn2<
  number,
  string | number | Date,
  string | number | Date
>;
