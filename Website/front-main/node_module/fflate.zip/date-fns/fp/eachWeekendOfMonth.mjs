// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachWeekendOfMonth as fn } from "../eachWeekendOfMonth.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachWeekendOfMonth = convertToFP(fn, 1);

// Fallback for modularized imports:
export default eachWeekendOfMonth;
