export declare const differenceInCalendarWeeks: import("./types.js").FPFn2<
  number,
  string | number | Date,
  string | number | Date
>;
