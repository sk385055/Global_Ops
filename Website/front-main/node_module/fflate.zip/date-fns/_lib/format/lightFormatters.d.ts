export declare const lightFormatters: {
  y(date: Date, token: string): string;
  M(date: Date, token: string): string;
  d(date: Date, token: string): string;
  a(date: Date, token: string): string;
  h(date: Date, token: string): string;
  H(date: Date, token: string): string;
  m(date: Date, token: string): string;
  s(date: Date, token: string): string;
  S(date: Date, token: string): string;
};
