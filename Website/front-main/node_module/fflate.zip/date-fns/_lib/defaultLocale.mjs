export { enUS as defaultLocale } from "../locale/en-US.mjs";
