import React, { useState } from 'react';
import { Automation } from './Automation';
import { AnimatedBackground } from '../components/3D/Background';
import { Header } from '../components/Layout/Header';
import image2 from "../images/Teams.jpg"
import journey from "../images/Journey_Map.png"
import Tracker from "../images/Tracker.png"
import ImageCard from './ImageCard';
const HomePage = () => {
    const [tab, setTab] = useState<number>(1);
    const renderPage = () => {
        switch (tab) {
            case 1:
                return <ImageCard img={journey} />;
            case 2:
                return <ImageCard img={Tracker} />;
            case 3:
                return <Automation />;
            default:
                return <ImageCard img={journey} />;
        }
    };
    return (
        <div className='min-h-screen'>
            <AnimatedBackground />
            <Header />
            {/* Tab Buttons */}
            <div className="grid grid-cols-3 gap-4 mb-8 w-fit mx-auto my-8">
                {([
                    { id: 1, name: 'Journey', color: 'bg-orange-600', icon: '🚀' },
                    { id: 2, name: 'Tracker', color: 'bg-blue-600', icon: '📍' },
                    { id: 3, name: 'Database', color: 'bg-purple-600', icon: '📊' }
                ]).map(({ id, name, color }) => (
                    <button
                        key={id}
                        onClick={() => setTab(id)}
                        className={`p-3 w-fit rounded-lg font-medium text-white flex items-center justify-between
               transition-all duration-300 ease-in-out
               ${tab === id ? `${color} shadow-lg scale-105` : 'bg-gray-700 hover:opacity-90'}
           `}
                    >
                        {name}
                    </button>
                ))}
            </div>

            {/* Render Selected Tab Content */}
            {renderPage()}
        </div>
    );
};
export default HomePage;