import { useState } from 'react';
import { motion } from 'framer-motion';
import { Header } from '../components/Layout/Header';
import { AnimatedBackground } from '../components/3D/Background';
import { PowerBIButton } from '../components/SOPSites/PowerBIButton';
import { ShareFolderButton } from '../components/SOPSites/ShareFolderButton';
import { ExternalLinkButton } from '../components/SOPSites/ExternalLinkButton';
import { powerBIReports, shareFolders, externalLinks } from '../data/navigationData';

import image2 from "../images/Teams.jpg"
import { BarChart2Icon, Folder, Link, PowerIcon, User } from 'lucide-react';

export const SOPSites = () => {
  const [activeSection, setActiveSection] = useState<'powerbi' | 'folders' | 'links' | 'team'>('links');
  const [activeLinks, setActiveLinks] = useState<any>("Global Ops");
  const linkButtons: any = ["Global Ops","Access Request","Employee","IT Centrals", "All Links"]
  const Links: any = {
    "Global Ops": [
    { name: 'Azure Queries', url: 'https://ncratleos-my.sharepoint.com/:o:/p/vv185114/EhFkhRAg0fpKscvRfT7VTMgBGR4bL26uESdVvW5Y8zGuwA' },
    { name: 'Azure Fabric', url: 'https://app.powerbi.com/groups/me/datawarehouses/cb2063e5-6f97-4507-858a-82b96f9264d8?experience=power-bi&clientSideAuth=0&noSignUpCheck=1' },
    { name: 'Dicontinuation Exception', url:'https://ncratleos.sharepoint.com/sites/SolutionsProductManagement/Shared%20Documents/Forms/AllItems.aspx?csf=1&web=1&e=9yF6sy&ovuser=6539da08%2Db835%2D422b%2Dbc32%2D76ca20bec464%2Cak250659%40ncratleos%2Ecom&OR=Teams%2DHL&CT=1715683570893&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yNDAzMjgyMTIwMCIsIkhhc0ZlZGVyYXRlZFVzZXIiOnRydWV9&cid=d42eaccf%2D6420%2D4e78%2Da524%2Dbcd80713bd69&FolderCTID=0x012000CFBAFC1992A6C64384B9305069D09045&id=%2Fsites%2FSolutionsProductManagement%2FShared%20Documents%2FGeneral%2FDiscontinuation%20Team'},
    { name: 'Sorucing Tracker', url: 'https://ncratleos.sharepoint.com/:x:/r/sites/NCRAtleosOpsAnalytics/_layouts/15/Doc.aspx?sourcedoc=%7BFB8F0C07-DE88-4320-8377-5A5B729B52C5%7D&file=Sourcing%20Request%20Tracker.xlsm&action=default&mobileredirect=true' },
    { name: 'NFC Configurator', url: 'http://sunatm4584.daytonoh.ncr.com:8004/OA_HTML/RF.jsp?function_id=29291&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&params=v9th8Qnuc-fzJVFu.7eYkQ&oas=CwgjFdn1z9KvqAksCiUDDA..' },
    { name: '2025 Key Accomplishments', url: '/key-accomplishments' }
    ],
    "Access Request":[
      { name: 'ERP Access', url: 'https://iis.ncrnet.ncratleos.com/spp/form/user_status.asp' },
      { name: 'Merlin Access', url: 'https://aim.ncratleos.com/ignite/login' },
      { name: 'NIAM', url: 'https://aim.ncratleos.com/ignite/dashboard'}
    ],
    "Employee":[
      { name: 'Workday', url: 'https://www.myworkday.com/ncratleos' },
      { name: 'ADP', url: 'https://launcher.myapps.microsoft.com/api/signin/0dc472c8-1651-4c53-b9a2-9b1898db3750?tenantId=6539da08-b835-422b-bc32-76ca20bec464' },
      { name: 'PF', url: 'https://retirals.myndsolution.com/rptPfLedger.aspx' },
      { name: 'HR Central', url: 'https://ncratleos.service-now.com/hrcentral'}

    ],
    "IT Centrals":[
      { name: 'IT Tickets', url: 'https://ncratleos.service-now.com/itcentral?id=index' },
      { name: 'GIT Hub', url:'https://github.com/ncratleos-hw-engineering/'},
      { name: 'Jira', url:'https://ncratleosengtools.atlassian.net/jira' }

    ],
    "All Links": [
      { name: 'Azure Fabric', url: 'https://app.powerbi.com/groups/me/datawarehouses/cb2063e5-6f97-4507-858a-82b96f9264d8?experience=power-bi&clientSideAuth=0&noSignUpCheck=1' },
      { name: 'Merlin', url: 'https://plm.ncratleos.com/ematrix/common/emxNavigator.jsp?appName=null' },
      { name: 'ERP', url: 'https://atmerpprod.daytonoh.ncr.com:4499/OA_HTML/RF.jsp?function_id=30923&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&oas=82kHgwXjYzrMspRRFkHZ2g..&params=T1u.pb0I9Lh3-O.ZxmqkQpWRAahwgBVrc3O95NrpEsbMCtilP5I4GhYfwyfajzOcrazwi6L3rV6ZU1L.hkZP0fg4W5W7cwmkBkorBVGi4Wk6UtGTOkMYMNdlg2gyl8ym7CvCI50UdjFM1D5HHrYKUiXubA.OVxxHr54ICGcP126hd3erBdUIa2dAU9c11DVNkDuOuARVnYWbqteu0WQ12hm3M3TKuTy4y0S3dyoIORPq.p.c4mfWmOXBqYyadV7Ygwiyq.uKtf1-o94ihKM98.KnGHwth3lv0fV96OkSu4k7Rn86OFw2sHNzSFsbi9DmCSkAI8ikIFlqSlVuA4HILcPaa5roXR8ZZHLdfIOvI7JluxqQQ8KcdXrH5i9VpXKNOHINgGr2c3LRUlKy4nduMYmaUAbcdiA6TTmke0Q5BJk9BpvP82WKZfzegw8uTV7Ak94wZogAa7MC41t-DW2KbE422NSeJz9p1leedAtKF64' },
      { name: 'OCP', url: 'https://fa-exur-saasfaprod1.fa.ocs.oraclecloud.com/fscmUI/faces/FuseWelcome?_afrLoop=8664184471372303&_afrWindowMode=0&_afrWindowId=169tqbu06p&_adf.ctrl-state=vh2q6e1ke_1&_afrFS=16&_afrMT=screen&_afrMFW=1318&_afrMFH=654&_afrMFDW=1366&_afrMFDH=768&_afrMFC=8&_afrMFCI=0&_afrMFM=0&_afrMFR=96&_afrMFG=0&_afrMFS=0&_afrMFO=0' },
      { name: 'GSDB', url: 'https://gsdb.ncratleos.com/prod/prod_wbcriteria.jsp' },
      { name: 'GPNet', url: 'https://login.microsoftonline.com/6539da08-b835-422b-bc32-76ca20bec464/saml2?SAMLRequest=jZLbbtswDIZfxdC9LMdWnFiIA2TN0BlIO6PJdrGbQVbYVIAsuaLcw9vPdhcga4FiVwQJHr6f5Aplazqx6cODvYPHHjBE1bYkv%2fmiWILMjrTgeUr5bA5U8pmi9022nPNcLhZFSqKf4FE7W5I0TkhUIfZQWQzShiGUpJwmBU3zQ8IFT8Qs%2b0Wi2rvglDNftD1qeypJ761wEjUKK1tAEZTYb252YugomrckFN8Oh5rW3%2fcHEm0QwYdh6JWz2Lfg9%2bCftIIfd7uSPITQoWBMa4yt8hbCaGQw4DBWrmWnboix6%2foWwqj5GkK1jSV2LyR6aY1FMe3jc6rurwSyXo3ZYpLtL%2bo%2fL5dnAWT9f7grdjHmbWYnboe%2b1bZ2RqvXaGOMe77yIAOUJPgeSMTOiXvlumGHZ3eo2WkMF%2b5XG%2fzreJcnfQQ%2fHv%2bMZdxJ27jVyjt098FZoy1MXPk8K44yWdJmmc0pT9OGNipL6SJXMk0aUDznE%2fXwIyNpSf7RNeGxd0DsHS%2f7%2bJrrPw%3d%3d&sso_nonce=AwABEgEAAAADAOz_BQD0__vD-lgp48qdLD1EQb8IpHQZAZ58cIfvznKemWOsmASmKHEB3r8LO5AT2rq6mEw0QAnmqAnF_bXS8B-jV6WLHBYgAA&client-request-id=c83ef279-a0a1-4605-b26b-d5d1565a95e0&mscrid=c83ef279-a0a1-4605-b26b-d5d1565a95e0' },
      { name: 'CFL', url: 'https://prodcust.ncratleos.com/cfl_listall.aspx' },
      { name: 'NCR University', url: 'https://ncratleos.csod.com/ui/lms-learner-home/home?tab_page_id=-200300006&tab_id=221000470' },
      { name: 'GitHub', url: 'https://github.com/' }
    ],

  }
  return (
    <div className="min-h-screen">
      <AnimatedBackground />
      <Header />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="grid grid-cols-4 gap-4 mb-8">
            {(['team', 'powerbi', 'folders', 'links'] as const).map((section) => (
              <button
                key={section}
                onClick={() => setActiveSection(section)}
                // Previous colors
                // ${activeSection === section
                //   ? 'bg-blue-600 text-white'
                //    : 'bg-white/80 text-gray-800 hover:bg-white/90'
                //  } 
                className={`p-3 rounded-lg font-medium transition-colors text-white
                  
                ${section === 'powerbi' ? 'bg-[#36454F]' :
                    section === 'folders' ? 'bg-[#36454F]' :
                      section === 'links' ? "bg-[#36454F]" :
                        "bg-[#36454F]"
                  }
                `}
              >
                {section === 'team' && <span className='flex w-full justify-between'>Team <User /></span>}
                {section === 'powerbi' && <span className='flex w-full justify-between'>Power BI Reports <BarChart2Icon /></span>}
                {section === 'folders' && <span className='flex w-full justify-between'>Share Folders <Folder /></span>}
                {section === 'links' && <span className='flex w-full justify-between'>Application Links <Link /></span>}

              </button>
            ))}
          </div>

          <motion.div
            key={activeSection}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            {activeSection === 'powerbi' && (
              powerBIReports.map((report) => (
                <PowerBIButton key={report.name} report={report} />
              ))
            )}

            {activeSection === 'folders' && (
              shareFolders.map((folder) => (
                <ShareFolderButton key={folder.name} folder={folder} />
              ))
            )}


            {activeSection === 'links' && (
              <>
                <div className="grid grid-cols-4 gap-4">
                  {
                    linkButtons.map((btn: any, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => setActiveLinks(btn)}
                        className="rounded-lg p-3 text-black font-semibold bg-[#f0f8ff]"
                      >
                        {btn}
                      </button>
                    ))
                  }
                </div>
                {Links[activeLinks].map((link: any) => (
                  <ExternalLinkButton key={link.name} link={link} />
                ))}
              </>
            )}



            {activeSection === 'team' && (
              <div className="bg-white/80 backdrop-blur-sm p-8 rounded-lg shadow-md text-center">
                <div className="flex justify-center mb-4">
                  <img src={image2} className="text-blue-600" />
                </div>
                <p className="text-gray-600">Team image would be displayed here</p>
              </div>
            )}
          </motion.div>
        </motion.div>
      </main>

    </div>
  );
};