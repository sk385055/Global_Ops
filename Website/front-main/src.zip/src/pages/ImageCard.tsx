import React, { FC, useState } from 'react'
interface ImageCardProps {
    img: string;
}
const ImageCard: FC<ImageCardProps> = ({ img }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <>
            <div className="bg-white/80 backdrop-blur-sm p-8 rounded-lg shadow-md text-center w-fit mx-auto">
                <div className="flex justify-center mb-4">
                    <img
                        src={img}
                        className="text-blue-600"
                        onClick={() => setIsOpen(true)}
                    />
                </div>
                <p className="text-gray-600">Team image would be displayed here</p>
            </div>
            {/* Fullscreen Zoom Modal */}
            {isOpen && (
                <div
                    className="fixed inset-0 bg-black bg-opacity-80 flex justify-center items-center z-50"
                    onClick={() => setIsOpen(false)}
                >
                    <img
                        src={img}
                        alt="Full Size"
                        className="max-w-full max-h-full w-[80%] rounded-lg shadow-lg transition-transform scale-100 hover:scale-105"
                    />
                </div>
            )}
        </>
    )
}
export default ImageCard