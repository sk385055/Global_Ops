import { AnimatedBackground } from '../components/3D/Background';
import { Header } from '../components/Layout/Header';

const pdfUrl = '/global_ops.pdf'; // place file in `public/global_ops.pdf`

export const KeyAccomplishments = () => {
  return (
    <div className="min-h-screen">
      <AnimatedBackground />
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto bg-white/80 backdrop-blur-sm p-6 rounded-lg shadow-md">
          <h1 className="text-2xl font-semibold mb-4 text-gray-800">
            Global Ops - Key Accomplishments
          </h1>
          <p className="text-gray-600 mb-4">
            The Key Accomplishments presentation is embedded below as a PDF. Use the built-in page
            controls in the viewer to move between slides, or open it in a new tab.
          </p>

          <div className="w-full h-[600px] border rounded-lg overflow-hidden mb-4 bg-gray-100">
            <iframe
              src={pdfUrl}
              title="Global Ops - Key Accomplishments"
              className="w-full h-full"
            />
          </div>

          <a
            href={pdfUrl}
            target="_blank"
            rel="noreferrer"
            className="text-blue-600 hover:text-blue-800 underline font-medium"
          >
            Open / download Key Accomplishments PDF
          </a>
        </div>
      </main>
    </div>
  );
};

