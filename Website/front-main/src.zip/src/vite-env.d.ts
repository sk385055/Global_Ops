/// <reference types="vite/client" />

declare module '*.pptx' {
  const src: string;
  export default src;
}
