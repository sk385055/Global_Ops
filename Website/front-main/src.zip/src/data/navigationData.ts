import { AutomationItem } from "../types";

export const powerBIReports = [
  { name: 'Risk Assessment', url: 'https://app.powerbi.com/links/6mhcfyUgA_?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare' },
  { name: 'Schedule Stability', url: 'https://app.powerbi.com/links/qfhtRDAfNe?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare' },
  { name: 'OTD Metrics', url: 'https://app.powerbi.com/links/PMBa1cCV5Q?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare' },
  { name: 'GOP', url: 'https://app.powerbi.com/links/zKHMAUdnWg?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare' },
  { name: 'ICOR-Namer', url: 'https://app.powerbi.com/groups/me/reports/8b76a558-8cd1-44f5-9936-f4141bfc969e/ReportSection?experience=power-bi' },
  { name: 'SR Modules', url: 'https://app.powerbi.com/groups/me/reports/d641a2c4-89d1-47a9-8296-d42d43f41624/a99befb148b6d3211ea9?experience=power-bi' },
  { name: 'IND POR', url: 'https://app.powerbi.com/links/u28k1gdyKk?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare&bookmarkGuid=b4df67ca-d92d-4363-8d00-b55ca1a4efba' },
  { name: 'IA Excess', url: 'https://app.powerbi.com/groups/me/reports/d794ff4f-4f95-4cb3-a210-5452650b3929/ReportSection52c339128cd1a685a8cc?ctid=6539da08-b835-422b-bc32-76ca20bec464&experience=power-bi' },
  { name: 'IO-Initial Scheduling Tracker', url: 'https://app.powerbi.com/links/8oTFQ-mAYJ?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare' },
  { name: 'Global Doc', url: 'https://app.powerbi.com/links/BDsHk644Yv?ctid=6539da08-b835-422b-bc32-76ca20bec464&pbi_source=linkShare' },
  { name: 'Production Status Report', url: 'https://app.powerbi.com/groups/me/reports/4f2bf96f-461e-4822-b3ae-0b196e38dccc/723603070b3952caa007?experience=power-bi' },
  { name: 'Order Tracking', url: 'https://app.powerbi.com/groups/me/reports/e2399563-c430-4d70-80be-bccd13b63836/aa4a4400664ba55b96f3?experience=power-bi' },
  { name: 'DEP POR -   (WIP) ', url: '' },
  { name: 'Feature WaterFall  -  (WIP) ', url: '' },
  { name: 'FFA  -   (WIP) ', url: '' }

];

export const shareFolders = 

[
  { name: 'POR', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Demand Planning\\POR and Changes' },
  { name: 'DEP POR', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Feature Forecast Files\\DEP POR' },
  { name: 'Backlog Changes', path: 'https://ncratleos.sharepoint.com/sites/NCRAtleosOpsAnalytics/Shared Documents/Forms/AllItems.aspx?newTargetListUrl=%2fsites%2fNCRAtleosOpsAnalytics%2fShared+Documents&viewpath=%2fsites%2fNCRAtleosOpsAnalytics%2fShared+Documents%2fForms%2fAllItems.aspx&OR=Teams-HL&CT=1706680475965&id=%2fsites%2fNCRAtleosOpsAnalytics%2fShared+Documents%2fGlobal+Ops+Analytics%2fNCR+Atleos+Backlog+changes&viewid=0f41fdff-85a6-4188-93a6-c5c7b80bc454' },
  { name: 'Schedule Stability', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\Schedule Stability' },
  { name: 'OTD & Lead Time', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\OTD & Leadtime' },
  { name: 'SFDC', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Demand Planning\\Sales Funnel' },
  { name: 'Global Doc', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\Daily Order Cover' },
  { name: 'PlantDet', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\Plandet' },
  { name: 'Rev Report', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\Revenue report' },
  { name: 'Unschedule Order', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\scheduling_intelligence_tool' },
  { name: 'Weekly Supply Plan', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\Weekly Supply Plan' },
  { name: 'Plant Feature Mix', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Feature Forecast Files\\Plant Feature Mix files' },
  { name: 'EC-Safe Demand', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Metrics\\Ennoconn Safe Demand' },
  { name: 'Work Instruction', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Work Instructions' },
  { name: 'Profile Tracker', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Profile Tracker' },
  { name: 'Projects', path: '\\\\wtc1501cifs.prod.local\\ORGSHARE\\TEAMS\\ERP Shared Folder\\NCR Atleos\\Atleos Operations Planning\\Global Ops Analytics\\Projects' }
  

];

export const externalLinks = [
  { name: 'Azure Queries', url: 'https://ncratleos-my.sharepoint.com/:o:/p/vv185114/EhFkhRAg0fpKscvRfT7VTMgBGR4bL26uESdVvW5Y8zGuwA' },
  { name: 'Azure Fabric', url: 'https://app.powerbi.com/groups/me/datawarehouses/cb2063e5-6f97-4507-858a-82b96f9264d8?experience=power-bi&clientSideAuth=0&noSignUpCheck=1' },
  { name: 'NFC Configurator', url: 'http://sunatm4584.daytonoh.ncr.com:8004/OA_HTML/RF.jsp?function_id=29291&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&params=v9th8Qnuc-fzJVFu.7eYkQ&oas=CwgjFdn1z9KvqAksCiUDDA..' },
  { name: 'Merlin', url: 'https://plm.ncratleos.com/ematrix/common/emxNavigator.jsp?appName=null' },
  { name: 'ERP', url: 'https://atmerpprod.daytonoh.ncr.com:4499/OA_HTML/RF.jsp?function_id=30923&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&oas=82kHgwXjYzrMspRRFkHZ2g..&params=T1u.pb0I9Lh3-O.ZxmqkQpWRAahwgBVrc3O95NrpEsbMCtilP5I4GhYfwyfajzOcrazwi6L3rV6ZU1L.hkZP0fg4W5W7cwmkBkorBVGi4Wk6UtGTOkMYMNdlg2gyl8ym7CvCI50UdjFM1D5HHrYKUiXubA.OVxxHr54ICGcP126hd3erBdUIa2dAU9c11DVNkDuOuARVnYWbqteu0WQ12hm3M3TKuTy4y0S3dyoIORPq.p.c4mfWmOXBqYyadV7Ygwiyq.uKtf1-o94ihKM98.KnGHwth3lv0fV96OkSu4k7Rn86OFw2sHNzSFsbi9DmCSkAI8ikIFlqSlVuA4HILcPaa5roXR8ZZHLdfIOvI7JluxqQQ8KcdXrH5i9VpXKNOHINgGr2c3LRUlKy4nduMYmaUAbcdiA6TTmke0Q5BJk9BpvP82WKZfzegw8uTV7Ak94wZogAa7MC41t-DW2KbE422NSeJz9p1leedAtKF64' },
  { name: 'OCP', url: 'https://fa-exur-saasfaprod1.fa.ocs.oraclecloud.com/fscmUI/faces/FuseWelcome?_afrLoop=8664184471372303&_afrWindowMode=0&_afrWindowId=169tqbu06p&_adf.ctrl-state=vh2q6e1ke_1&_afrFS=16&_afrMT=screen&_afrMFW=1318&_afrMFH=654&_afrMFDW=1366&_afrMFDH=768&_afrMFC=8&_afrMFCI=0&_afrMFM=0&_afrMFR=96&_afrMFG=0&_afrMFS=0&_afrMFO=0' },
  { name: 'ERP Request', url: 'https://iis.ncrnet.ncratleos.com/spp/form/user_status.asp' },
  { name: 'Merlin Request', url: 'https://aim.ncratleos.com/ignite/login' },
  { name: 'ADP', url: 'https://launcher.myapps.microsoft.com/api/signin/0dc472c8-1651-4c53-b9a2-9b1898db3750?tenantId=6539da08-b835-422b-bc32-76ca20bec464' },
  { name: 'IT Central', url: 'https://ncratleos.service-now.com/itcentral?id=index' },
  { name: 'GIT Hub', url:'https://github.com/ncratleos-hw-engineering/'},
  { name: 'NCR University', url: 'https://www.linkedin.com/learning/search?keywords=&upsellOrderOrigin=default_guest_learning&trk=learning-topics_learning-search-bar_search-submit' }

];






export const automationItems: AutomationItem[] = [
  { name: 'New Demand', excelPath: 'E:/_Projects/Batch Script/Azure.bat', imagePath: '/Azure_Vs_IND_POR.jpg' },
  { name: 'NFC', excelPath: 'E:/_Projects/Batch Script/NFC.bat', imagePath: '/NFC.jpg' },
  { name: 'Shipments', excelPath: 'E:/_Projects/DEP POR/Azure Vs IND POR/Azure_Query.pdf', imagePath: '/Azure_Query.jpg' },
  { name: 'Backlog', excelPath: 'E:/_Projects/DEP POR/Azure Vs IND POR/Azure_Query.pdf', imagePath: '/Azure_Query.jpg' },
  { name: 'RFC', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Features Demand', excelPath: 'E:/_Projects/Batch Script/DEP.bat', imagePath: '/DEP_POR.jpg' },
  { name: 'Sourcing Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Low Usage Analytics', excelPath: 'E:/_Projects/Batch Script/Low_Usage.bat', imagePath: '/Low_Usage.jpg' },
  { name: 'Unique Feature Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'E&O Feature Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Expedite Features Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Generic Mix Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Feature Mix Changes Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Pre F-Mix File', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Discontinuation Feature Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Shipment Feature Mix Analytics', excelPath: '', imagePath: '/WIP.jpg' },
  { name: 'Publish File', excelPath: '', imagePath: '/WIP.jpg' }
];