import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { SOPSites } from './pages/SOPSites';
import HomePage from './pages/HomePage';
import { KeyAccomplishments } from './pages/KeyAccomplishments';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/signin" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/" element={<SOPSites />} />
        <Route path="/automation" element={<HomePage />} />
        <Route path="/key-accomplishments" element={<KeyAccomplishments />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;